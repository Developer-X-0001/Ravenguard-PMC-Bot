aa = "> Tom"
print(aa[2:])
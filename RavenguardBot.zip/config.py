TOKEN = "MTExMjAyMTMwOTk1ODkyNjQxOA.GZBsKD.tFOj1NLFCv99ntNCpreZT4CIvZs_5evjlwz1nM"
APPLICATION_ID = 1112021309958926418
PREFIX = "!"

ADD_EMOJI = "<:add:1113938652519731251>"
EDIT_EMOJI = "<:edit:1114313358695465041>"
BACK_EMOJI = "<:back:1114099506225614860>"
DONE_EMOJI = "<:done:1113930452072411136>"
SAVE_EMOJI = "<:save:1114669682440540170>"
SEND_EMOJI = "<:send:1114671262531330078>"
WARN_EMOJI = "<:warn:1113930778347327555>"
ERROR_EMOJI = "<:error:1113931241251668059>"
ARROW_EMOJI = "<:arrow:1112041137650286692>"
LOAD_EMOJI = "<a:loading:1113930448381419620>"
MAYBE_EMOJI = "<:maybe:1115386215466799156>"
DELETE_EMOJI = "<:delete:1114671266104881162>"
SETTINGS_EMOJI = "<:settings:1114094845347242115>"

DEPLOYMENT_CHANNEL_ID = 1112039488353468556
APPLICATION_CHANNEL_ID = 1044266759202537495

BOT_OPERATOR_ROLE_ID = 1115943607350861884
VERIFIED_ROLE_ID = 1098187364033105950
PIGEON_DIVISION_ROLE_ID = 1083930367813230723
ENLISTED_ROLE_ID = 1044265782307213382

RAVEN_RED = 0xA90C0D
RAVEN_ICON = 'https://cdn.discordapp.com/icons/1041533895268651038/8795824b3873a3e88e8070b68ec851a4.png?size=512'

RANKS = {
    "T9": {
        "name": "Cadet",
        "id": 1066549694886588507,
        "emoji": "<:1_Cadet:1114857363346821160>",
        "role": 0,
        "url": "https://i.imgur.com/w8C7oMa.png"
    },

    "T8": {
        "name": "Private",
        "id": 1066551026968178768,
        "emoji": "<:2_Private:1114857366568054816>",
        "role": 0,
        "url": "https://i.imgur.com/SslCUxy.png"
    },
    
    "T7": {
        "name": "Private First Class",
        "id": 1066551452253818911,
        "emoji": "<:3_PrivateFirstClass:1114857368866525184>",
        "role": 0,
        "url": "https://i.imgur.com/hXBYBJz.png"
    },
    
    "T6B": {
        "name": "Lance Corporal",
        "id": 1066551773160026184,
        "emoji": "<:4_LanceCorporal:1114857371999670272>",
        "role": 0,
        "url": "https://i.imgur.com/TpirQpT.png"
    },
    
    "T6A": {
        "name": "Corporal",
        "id": 1066552090303934474,
        "emoji": "<:5_Corporal:1114857375204130837>",
        "role": 0,
        "url": "https://i.imgur.com/tzeDzq1.png"
    },
    
    "T5": {
        "name": "Sergeant",
        "id": 1066552388539908166,
        "emoji": "<:6_Sergeant:1114857377435488318>",
        "role": 0,
        "url": "https://i.imgur.com/41T9URo.png"
    },
    
    "T4": {
        "name": "Staff Sergeant",
        "id": 1066553403951562812,
        "emoji": "<:7_StaffSergeant:1114857381315223592>",
        "role": 0,
        "url": "https://i.imgur.com/tEHWNmm.png"
    },
    
    "T3": {
        "name": "Sergeant First Class",
        "id": 1066553817820303500,
        "emoji": "<:8_SergeantFirstClass:1114857384448368672>",
        "role": 0,
        "url": "https://i.imgur.com/NoQ8Bhz.png"
    },
    
    "T2": {
        "name": "First Sergeant",
        "id": 1066554014017257532,
        "emoji": "<:9_FirstSergeant:1114857386809761842>",
        "role": 0,
        "url": "https://i.imgur.com/0kR13SE.png"
    },
    
    "T1A": {
        "name": "Sergeant Major",
        "id": 1066554183358087268,
        "emoji": "<:10_SergeantMajor:1114857390022594682>",
        "role": 0,
        "url": "https://i.imgur.com/SohzXsV.png"
    },
    
    "J4": {
        "name": "Warrant Officer Class 3",
        "id": 1066554503685480538,
        "emoji": "<:11_WarrantOfficerClass3:1114857392111366207>",
        "role": 0,
        "url": "https://i.imgur.com/4jgfPzk.png"
    },
    
    "J3": {
        "name": "Warrant Officer Class 2",
        "id": 1066554806887526400,
        "emoji": "<:12_WarrantOfficerClass2:1114857395965935717>",
        "role": 0,
        "url": "https://i.imgur.com/K6CxRW1.png"
    },
    
    "J2": {
        "name": "Warrant Officer Class 1",
        "id": 1066554960105455698,
        "emoji": "<:13_WarrantOfficerClass1:1114857399388483714>",
        "role": 0,
        "url": "https://i.imgur.com/hxRw7FR.png"
    },
    
    "J1": {
        "name": "Chief Warrant Officer",
        "id": 1066554999678717993,
        "emoji": "<:14_ChiefWarrantOfficer:1114857403536646164>",
        "role": 0,
        "url": "https://i.imgur.com/u8pXXlK.png"
    },
    
    "H7": {
        "name": "2nd Lieutenant",
        "id": 1066555557034590349,
        "emoji": "<:15_SecondLieutenant:1114857405763825776>",
        "role": 0,
        "url": "https://i.imgur.com/W0Dn5RW.png"
    },
    
    "H6": {
        "name": "1st Lieutenant",
        "id": 1066555433000648745,
        "emoji": "<:16_FirstLieutenant:1114857410482421841>",
        "role": 0,
        "url": "https://i.imgur.com/6SIi18R.png"
    },
    
    "H5": {
        "name": "Captain",
        "id": 1066555606506414092,
        "emoji": "<:17_Captain:1114857413892395048>",
        "role": 0,
        "url": "https://i.imgur.com/6JoZUDO.png"
    },
    
    "H4": {
        "name": "Major",
        "id": 1066555667571298344,
        "emoji": "<:18_Major:1114857415825952778>",
        "role": 0,
        "url": "https://i.imgur.com/m9fgeEO.png"
    },
    
    "H3": {
        "name": "Lieutenant Colonel",
        "id": 1066555755706204161,
        "emoji": "<:19_LieutenantColonel:1114857419223347220>",
        "role": 0,
        "url": "https://i.imgur.com/neKxfir.png"
    },
    
    "H2": {
        "name": "Colonel",
        "id": 1066555834567508038,
        "emoji": "<:20_Colonel:1114857422700413038>",
        "role": 0,
        "url": "https://i.imgur.com/oYRfhDv.png"
    },
    
    "H1": {
        "name": "Brigadier General",
        "id": 1042927328155668581,
        "emoji": "<:21_BrigadierGeneral:1114857425934237718>",
        "role": 0,
        "url": "https://i.imgur.com/3pGGy89.png"
    },

    "C2": {
        "name": "Vice Subleader",
        "id": 1043552841731670136,
        "emoji": "<:23_ViceSubleader:1114857429759426560>",
        "role": 0,
        "url": "https://i.imgur.com/5SqzLwk.png"
    },
    
    "C1": {
        "name": "Subleader",
        "id": 1043552651968774205,
        "emoji": "<:24_Subleaders:1114857433383313449>",
        "role": 0,
        "url": "https://i.imgur.com/n9eekkt.png"
    },
    
    "A4": {
        "name": "Vice Secretary of Defence",
        "id": 1044466409545158736,
        "emoji": "<:25_ViceSecretaryofDefence:1114857437372088340>",
        "role": 0,
        "url": "https://i.imgur.com/ogJP2nb.png"
    },
    
    "A3": {
        "name": "Secretary of Defence",
        "id": 1044466404210004059,
        "emoji": "<:26_SecretaryofDefence:1114857439465058365>",
        "role": 0,
        "url": "https://i.imgur.com/7K85czC.png"
    },
    
    "A2": {
        "name": "Deputy Chief of Defence",
        "id": 1041536247069421589,
        "emoji": "<:27_DeputyChiefofDefence:1114857442845655120>",
        "role": 0,
        "url": "https://i.imgur.com/rdzW0R9.png"
    },
    
    "A1": {
        "name": "Chief of Defence",
        "id": 1041536155377737839,
        "emoji": "<:28_CheifofDefence:1114857446490505216>",
        "role": 0,
        "url": "https://i.imgur.com/sCWtHJz.png"
    },
}

RANK_LIST = ['T9', 'T8', 'T7', 'T6B', 'T6A', 'T5', 'T4', 'T3', 'T2', 'T1A', 'J4', 'J3', 'J2', 'J1', 'H7', 'H6', 'H5', 'H4', 'H3', 'H2', 'H1', 'C2', 'C1', 'A4', 'A3', 'A2', 'A1']
NON_HEX_ALPHABETS = ['G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

MEDALS = [
    {
        "name": "The Distinguished Service Star",
        "description": "Given to members who have shown exceptional vigilance, performance, skill, and attention to detail often in dangerous other otherwise high-pressure situations. They can keep a cool head and have demonstrated extraordinary acts of heroism in at least 1 deployment. Must be recognized by all squad members and the host to have played a significant role in the success of the operation/deployment.",
        "icon_url": "https://i.imgur.com/dNTRL6r.png",
        "emoji": "<:TheDistinguishedServiceStar:1114953764290449588>",
        "role": 1104540066384187402,
        "color": 0x0033ff
    },
    {
        "name": "The Raven\'s Merit Medal",
        "description": "Given to members who have shown exceptional vigilance, performance, skill, and attention to detail often in dangerous other otherwise high-pressure situations. They can keep a cool head and have demonstrated extraordinary acts of heroism in at least 3 deployments. Must be recognized by all squad members and the host to have played a significant role in the success of the operation/deployment.",
        "icon_url": "https://i.imgur.com/y7pl4xT.png",
        "emoji": "<:TheRavensMerit:1114947349026979960>",
        "role": 1104540114891325451,
        "color": 0xa0a0a0
    },
    {
        "name": "The Raven\'s Cross Medal",
        "description": "Given to members who have shown exceptional vigilance, performance, skill, and attention to detail often in dangerous other otherwise high-pressure situations. They can keep a cool head and have demonstrated extraordinary acts of heroism in at least 5 deployments. Must be recognized by all squad members and the host to have played a significant role in the success of the operation/deployment.",
        "icon_url": "https://i.imgur.com/VG4zg3Z.png",
        "emoji": "<:TheRavensCross:1115284264028733521>",
        "role": 1104540169484386484,
        "color": 0xa20000
    },
    {
        "name": "The Marauder Medal",
        "description": "Given to squad leads who successfully complete a compound raid without any KIA, or MIA. I.E. all members that were present at the start must be there at the end.",
        "icon_url": "https://i.imgur.com/HNIzczJ.png",
        "emoji": "<:TheMarauder:1114956853881872405>",
        "role": 1104540203063984230,
        "color": 0xf85900
    },
    {
        "name": "The Unbroken Spirit Award",
        "description": "Given to members who, as the last one alive, completed the mission with a confirmation of no evac coming for them. They earned this medal by pure determination up until the last second.",
        "icon_url": "https://i.imgur.com/7YWPcQd.png",
        "emoji": "<:TheUnbrokenSpirit:1114964926914629674>",
        "role": 1104540233883717682,
        "color": 0x01ff85
    },
    {
        "name": "The Brothers In Arms Award",
        "description": "Given to members who managed to save a squadmate or civilian even under the most dire circumstances.",
        "icon_url": "https://i.imgur.com/W2eIUYB.png",
        "emoji": "<:BrothersinArms:1114973521769140276>",
        "role": 1104540271796031491,
        "color": 0x140000
    },
    {
        "name": "The \"Houdini\" Medal",
        "description": "Awarded to those who manage to escape from seemingly inescapable situations.",
        "icon_url": "https://i.imgur.com/ApNCy27.png",
        "emoji": "<:TheHoudini:1114977333951070328>",
        "role": 1104540303244931203,
        "color": 0xffd600
    },
    {
        "name": "The Swift Strike Medal",
        "description": "Awarded to members who completed a large operation very quickly without any KIA. Estimated time must be greater than 75 minutes.",
        "icon_url": "https://i.imgur.com/PIMTUPp.png",
        "emoji": "<:TheSwiftStrike:1114987770620944444>",
        "role": 1104540377433767977,
        "color": 0xf89500
    },
    {
        "name": "Purple Heart Award",
        "description": "Given to members who make it through a realistic deployment using all their heals, as well as getting downed at least once.",
        "icon_url": "https://i.imgur.com/HzZ7OfJ.png",
        "emoji": "<:ThePurpleHeart:1114983632784871494>",
        "role": 1104540405460111401,
        "color": 0x8369e7
    },
    {
        "name": "The Guardian Angel Award",
        "description": "Given to members who put their own lives on the line to protect the VIP. The VIP must not take any damage, and the entire squad must make it back alive.",
        "icon_url": "https://i.imgur.com/8mAMkWJ.png",
        "emoji": "<:TheGuardianAngel:1114986140026552482>",
        "role": 1104540438746120223,
        "color": 0x43ffff
    },
]